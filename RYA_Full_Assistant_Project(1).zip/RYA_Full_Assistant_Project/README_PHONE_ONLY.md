# ♠️R.Y.A♠️ — phone-only Android build

This is a Capacitor Android project. The repository includes a GitHub Actions workflow that builds a **debug APK** in the cloud. You can do the setup from an Android phone using Chrome and GitHub's mobile website. No computer is required.

## What is implemented in this starter

- Futuristic responsive assistant UI.
- Local/offline basic commands: date, time, identity, capability/help responses.
- On-device notes stored in localStorage.
- Public Wikipedia search (online).
- Weather lookup using Open-Meteo geocoding and forecast APIs (online).
- Optional online AI using an OpenAI-compatible chat-completions endpoint.
- Optional image question using a configured vision-capable endpoint; photo is sent only after the user taps Analyze.
- Android camera capture through the Capacitor Camera plugin, with runtime permission prompt.
- Speech synthesis and browser speech recognition when the Android WebView supports them.
- A small web service-worker cache for the browser/PWA version.
- Vite bundles the Capacitor JavaScript imports into the Android web assets.

## Important limits

- The APK workflow builds a **debug APK**, not a Play Store release. Android may show a warning when installing an APK from outside the Play Store.
- An AI endpoint and any required credentials are not included. Without one, public research and local commands still work, but free-form AI chat is not available.
- A provider API key entered in Settings stays in app memory only and is cleared when the app closes. A key in a mobile app is never fully secret from a determined device owner; a private backend proxy is safer. Never put a personal key into source files or a public repository.
- Speech recognition depends on Android WebView/device support and may not work on every phone. Typed chat and speech output are separate features.
- Camera capture requires Android permission. Image analysis requires a configured vision-capable AI endpoint and only uploads after the Analyze button is pressed.
- Weather and public research require internet. Notes and basic commands work offline after the app has been opened at least once; cached UI availability depends on Android WebView storage behavior.
- This starter does not silently monitor, record, or control other apps/devices. It does not access private databases.
- This workflow is not yet a tested release build. Verify the GitHub Actions run and test the installed APK on the target phone.

## Build from Android phone only

1. Download this ZIP and extract it with your Android Files app.
2. Open https://github.com in Chrome and sign in or create a GitHub account.
3. Create a **Public** repository named `rya-assistant` (public is simplest for GitHub Actions on a free account; don't upload secrets).
4. In the repository, use **Add file → Upload files**. Upload the contents of this project ZIP, including the hidden `.github` folder. If the mobile upload flow hides dot-folders, create `.github/workflows/android-apk.yml` manually in GitHub and paste the workflow contents from this project.
5. Ensure the workflow file path is exactly `.github/workflows/android-apk.yml` and the branch is `main`.
6. Commit the files. The cloud workflow runs `npm install`, bundles the web assets with Vite, creates the Capacitor Android project, and compiles the debug APK.
7. Open the repository's **Actions** tab. If GitHub asks, enable Actions. Select **Build RYA Android APK** and choose **Run workflow**.
8. Wait for the run to finish with a green check. Open the run and find **Artifacts → rya-debug-apk**.
9. Download the artifact ZIP to your phone, extract it, then tap `app-debug.apk`.
10. If Android asks, allow your browser/files app to install unknown apps for this installation, review the prompt, and install. You can turn that permission off again afterward.

## Updating the app

Edit the files under `www/` in the GitHub repository and commit. The workflow also runs when relevant files change on `main`. Download the new artifact and install it over the old debug app. Keep the same `appId` to preserve app identity.

## AI endpoint setup

Use a trusted HTTPS endpoint that accepts an OpenAI-compatible `/chat/completions` request. The endpoint must allow requests from the app and return `choices[0].message.content`. For image analysis, it must also support image content in the request. Do not use a random proxy or share your key. The model name must match the provider's supported model.

## Windows

The `www/` web app is also the shared UI source for a future Windows wrapper. This repository's workflow currently builds Android only. A Windows installer is not included in this project.
