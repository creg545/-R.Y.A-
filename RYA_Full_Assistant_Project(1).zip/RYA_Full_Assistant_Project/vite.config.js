import { defineConfig } from 'vite';
import { resolve } from 'node:path';

export default defineConfig({
  root: 'www',
  publicDir: 'public',
  base: './',
  build: {
    outDir: '../dist',
    emptyOutDir: true,
    rollupOptions: {
      input: resolve(process.cwd(), 'www/index.html')
    }
  }
});
