import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

const $ = (id) => document.getElementById(id);
const state = { endpoint: '', key: '', model: 'gpt-4o-mini', photoData: null, busy: false };
const safeText = (value) => String(value ?? '').replace(/[<>]/g, '');

function addMessage(role, text) {
  const item = document.createElement('div'); item.className = `message ${role}`;
  if (role === 'assistant') { const who = document.createElement('div'); who.className = 'speaker'; who.textContent = 'R.Y.A.'; item.append(who); }
  const body = document.createElement('div'); body.textContent = text; item.append(body); $('messages').append(item); $('messages').scrollTop = $('messages').scrollHeight;
}
function setStatus() {
  const online = navigator.onLine; $('connectionDot').classList.toggle('online', online);
  $('connectionText').textContent = online ? 'NETWORK AVAILABLE' : 'OFFLINE MODE';
  $('coreStatus').textContent = online ? 'Local systems ready · Network available' : 'Local systems ready · Offline';
}
window.addEventListener('online', setStatus); window.addEventListener('offline', setStatus); setStatus();

const localAnswers = (raw) => {
  const q = raw.toLowerCase();
  if (/time|clock/.test(q)) return `The time on this device is ${new Date().toLocaleTimeString()}.`;
  if (/date|today|day is it/.test(q)) return `Today is ${new Date().toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'})}.`;
  if (/your name|who are you/.test(q)) return 'I am ♠ R.Y.A ♠, your personal assistant interface.';
  if (/what can you do|capabilit/.test(q)) return 'I can manage on-device notes, answer basic commands, search public reference sources, check weather, use spoken output, and capture a photo when you grant permission. Advanced AI needs a configured online endpoint.';
  if (/help|commands/.test(q)) return 'Try: “What time is it?”, “What can you do?”, “Search public information about Mars”, or use the research and weather panels.';
  return null;
};

async function askAI(prompt, imageData = null) {
  if (!state.endpoint || !navigator.onLine) return null;
  const content = imageData ? [
    { type: 'text', text: prompt },
    { type: 'image_url', image_url: { url: imageData } }
  ] : prompt;
  const headers = { 'Content-Type': 'application/json' };
  if (state.key) headers.Authorization = `Bearer ${state.key}`;
  const response = await fetch(state.endpoint, { method: 'POST', headers, body: JSON.stringify({ model: state.model, messages: [{ role: 'system', content: 'You are R.Y.A., a helpful, clear personal assistant. Be honest about uncertainty. Use only public or user-authorized information. Do not claim to control devices or access data unless an available feature actually did so.' }, { role: 'user', content }], temperature: 0.5 }) });
  if (!response.ok) throw new Error(`AI service returned HTTP ${response.status}. Check the endpoint, model, and credentials.`);
  const data = await response.json();
  return data.choices?.[0]?.message?.content ?? 'The AI service returned no message.';
}
async function sendMessage(text) {
  const prompt = text.trim(); if (!prompt || state.busy) return;
  addMessage('user', prompt); $('prompt').value = ''; state.busy = true; $('sendBtn').disabled = true;
  try {
    const local = localAnswers(prompt);
    if (local) { addMessage('assistant', local); speak(local); return; }
    try { const answer = await askAI(prompt); if (answer) { addMessage('assistant', answer); speak(answer); return; } }
    catch (error) { addMessage('assistant', `Online AI could not respond: ${error.message}`); return; }
    addMessage('assistant', 'I can handle basic commands offline. For this question, connect an AI-compatible endpoint in Settings or use Public Research to look up a topic.');
  } finally { state.busy = false; $('sendBtn').disabled = false; }
}
$('sendBtn').addEventListener('click', () => sendMessage($('prompt').value));
$('prompt').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage($('prompt').value); } });
document.querySelectorAll('[data-command]').forEach(b => b.addEventListener('click', () => sendMessage(b.dataset.command)));
$('clearChat').addEventListener('click', () => { $('messages').replaceChildren(); addMessage('assistant','Conversation cleared.'); });

function speak(text) { if (!('speechSynthesis' in window)) return; window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text); utterance.rate = 1; window.speechSynthesis.speak(utterance); }
$('voiceBtn').addEventListener('click', () => {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) { addMessage('assistant','Speech recognition is not available in this Android WebView. You can still use typed messages and spoken replies where supported.'); return; }
  const recognition = new Recognition(); recognition.lang = navigator.language || 'en-US'; recognition.interimResults = false; recognition.maxAlternatives = 1;
  $('voiceBtn').textContent = 'Listening…';
  recognition.onresult = event => sendMessage(event.results[0][0].transcript);
  recognition.onerror = event => addMessage('assistant',`Voice input error: ${event.error}. Check microphone permission and try again.`);
  recognition.onend = () => $('voiceBtn').textContent = '🎙 Voice';
  try { recognition.start(); } catch { $('voiceBtn').textContent = '🎙 Voice'; }
});

async function research(query) {
  if (!navigator.onLine) throw new Error('Research needs an internet connection.');
  const url = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrlimit=5&prop=extracts&exintro=1&explaintext=1&format=json&origin=*`;
  const response = await fetch(url); if (!response.ok) throw new Error('Public search is unavailable right now.');
  const data = await response.json(); return Object.values(data.query?.pages ?? {}).sort((a,b)=>(a.index??0)-(b.index??0));
}
$('searchBtn').addEventListener('click', async () => {
  const q = $('searchQuery').value.trim(); if (!q) return; $('searchResults').textContent = 'Searching public sources…';
  try { const pages = await research(q); $('searchResults').replaceChildren(); if (!pages.length) { $('searchResults').textContent='No matching pages found.'; return; }
    pages.forEach(page => { const box=document.createElement('div');box.className='result-item';const a=document.createElement('a');a.href=`https://en.wikipedia.org/?curid=${page.pageid}`;a.target='_blank';a.rel='noopener';a.textContent=page.title;const p=document.createElement('p');p.textContent=(page.extract||'').slice(0,260)+(page.extract?.length>260?'…':'');box.append(a,p);$('searchResults').append(box); });
  } catch(e) { $('searchResults').textContent=e.message; }
});

$('weatherBtn').addEventListener('click', async () => {
  const city=$('weatherCity').value.trim(); if(!city)return; $('weatherResult').textContent='Looking up location…';
  try { if(!navigator.onLine)throw new Error('Weather requires internet.');
    const geo=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`).then(r=>r.json());const place=geo.results?.[0];if(!place)throw new Error('Location not found.');
    const weather=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph`).then(r=>r.json());const c=weather.current;
    $('weatherResult').textContent=`${place.name}, ${place.admin1||place.country}: ${Math.round(c.temperature_2m)}°F (feels like ${Math.round(c.apparent_temperature)}°F), humidity ${c.relative_humidity_2m}%, wind ${Math.round(c.wind_speed_10m)} mph.`;
  } catch(e) { $('weatherResult').textContent=e.message; }
});

function loadNotes(){const notes=JSON.parse(localStorage.getItem('rya_notes')||'[]');$('notesList').replaceChildren();notes.forEach((note,i)=>{const row=document.createElement('div');row.className='note-item';const span=document.createElement('span');span.textContent=note;const del=document.createElement('button');del.textContent='Delete';del.addEventListener('click',()=>{const all=JSON.parse(localStorage.getItem('rya_notes')||'[]');all.splice(i,1);localStorage.setItem('rya_notes',JSON.stringify(all));loadNotes();});row.append(span,del);$('notesList').append(row);});}
$('saveNote').addEventListener('click',()=>{const value=$('noteInput').value.trim();if(!value)return;const notes=JSON.parse(localStorage.getItem('rya_notes')||'[]');notes.unshift(value);localStorage.setItem('rya_notes',JSON.stringify(notes.slice(0,100)));$('noteInput').value='';loadNotes();});loadNotes();

$('cameraBtn').addEventListener('click', async () => {
  try {
    let photo;
    if (Capacitor.isNativePlatform()) photo = await Camera.getPhoto({ quality: 85, allowEditing: false, resultType: CameraResultType.Base64, source: CameraSource.Prompt });
    else { const input=document.createElement('input');input.type='file';input.accept='image/*';input.capture='environment';input.click();input.onchange=async()=>{const file=input.files?.[0];if(!file)return;const reader=new FileReader();reader.onload=()=>showPhoto(reader.result);reader.readAsDataURL(file);};return; }
    showPhoto(`data:image/${photo.format||'jpeg'};base64,${photo.base64String}`);
  } catch(e) { $('cameraStatus').textContent=`Camera not opened: ${e.message||'permission cancelled'}`; }
});
function showPhoto(data){state.photoData=data;$('cameraPreview').src=data;$('cameraPreview').classList.remove('hidden');$('analyzePhoto').classList.remove('hidden');$('cameraStatus').textContent='Photo selected on this device. It is not uploaded unless you press Analyze.';}
$('analyzePhoto').addEventListener('click',async()=>{if(!state.photoData)return; if(!state.endpoint){$('cameraStatus').textContent='Configure an AI-compatible vision endpoint first.';return;} $('cameraStatus').textContent='Sending photo to your configured AI service…';try{const answer=await askAI('Describe this image. Only describe what is visibly present.',state.photoData);addMessage('assistant',answer||'No analysis returned.');$('cameraStatus').textContent='Analysis complete. Check the conversation.';}catch(e){$('cameraStatus').textContent=`Analysis failed: ${e.message}`;}});

$('saveSettings').addEventListener('click',()=>{
  const endpoint=$('apiEndpoint').value.trim(); if(endpoint && !/^https:\/\//i.test(endpoint)){ $('settingsStatus').textContent='Use an HTTPS endpoint for network safety.';return; }
  state.endpoint=endpoint;state.key=$('apiKey').value;state.model=$('modelName').value.trim()||'gpt-4o-mini';$('settingsStatus').textContent=endpoint?'Endpoint applied for this app session. API key is memory-only.':'No AI endpoint configured. Public research still works.';
});

if ('serviceWorker' in navigator && !Capacitor.isNativePlatform()) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
