♠️R.Y.A♠️ — FULL ASSISTANT PROJECT

START HERE: read README_PHONE_ONLY.md.

This ZIP is the source project, not a ready-made APK. It includes a GitHub Actions cloud workflow that can build a debug APK using only your Android phone. A successful cloud build and real-device test are still required before calling the app verified.

The project includes local commands and notes, public web research, weather, optional AI endpoint configuration, permission-based camera capture, and voice features where supported.
